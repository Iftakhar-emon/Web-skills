<?php
$host="localhost"; 
$username="root"; 
$password=""; 
$db_name="online_food"; 
$tbl_name="registration";
 
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
$conn = new mysqli($host, $username, $password, $db_name);

$myusername=$_POST['name']; 
$myusermobile=$_POST['mobile']; 
$myuseremail=$_POST['email'];
$myuserpassword=$_POST['password'];
$myuserdeliveryplace=$_POST['delivery_place'];
 
$sql = "INSERT INTO registration (Name,Mobile,Email,Password,DeliveryPlace)
VALUES ('$myusername','$myusermobile','$myuseremail','$myuserpassword','$myuserdeliveryplace')";
if ($conn->query($sql) === TRUE) {
    echo "New User created successfully";
	?>
	
	 <br><a href="login.php">Back To login</a>
	 
<?php
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>