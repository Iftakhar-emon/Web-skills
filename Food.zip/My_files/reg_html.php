<!doctype html>
<html>
	<head>
		<title>www.Hat-Bazar.com</title>
		<link rel="stylesheet" href="food.css">
		<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
	
	</head>
	<body>
		<script src="js/bootstrap.min.js" type="text/javascript"></script>
		<script src="js/jquery-3.1.1.slim.min.js" type="text/javascript"></script>
			<div class="add">
				<form action="reg.php" method="POST">
					<div class="formtag">
						<fieldset>
							<table>
								<tr>
									<td style="color:white;">Name:</td>
									<td><input type="text" name="name" placeholder="Name"></td>
								</tr>
								<br>
								<tr>
									<td style="color:white;">Mobile:</td>
									<td><input type="digit" name="mobile" placeholder="Mobile"></td>
								</tr>
								<br>
								<tr>
									<td style="color:white;">Email:</td>
									<td><input type="text" name="email" placeholder="email"></td>
								</tr>
								<br>
								<tr>
									<td style="color:white;">Password:</td>
									<td><input type="text" name="password" placeholder="password"></td>
								</tr>
								<br>
								<tr>
									<td style="color:white;">Delivery Place:</td>
									<td><input type="text" name="delivery_place" placeholder="Delivery Place"></td>
								</tr>
							</table>
						</fieldset>
					</div>
					
					<input style="margin:120px"; type="submit" name="Signin" value="Submit"/>
				</form>
			</div>
		</body>
	</html>